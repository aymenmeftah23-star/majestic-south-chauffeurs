import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import {
  getAllClients, getClientById, createClient, updateClient, deleteClient,
  getAllChauffeurs, getChauffeurById, createChauffeur, updateChauffeur, deleteChauffeur,
  getAllVehicles, getVehicleById, createVehicle, updateVehicle, deleteVehicle,
  getAllDemands, getDemandById, createDemand, updateDemand, deleteDemand,
  getAllMissions, getMissionById, createMission, updateMission, deleteMission,
  getAllQuotes, getQuoteById, createQuote, updateQuote, deleteQuote,
  getAllAlerts, getAlertById, createAlert, updateAlert, deleteAlert,
} from "./db";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(async opts => {
      // Si utilisateur authentifié, le retourner
      if (opts.ctx.user) return opts.ctx.user;
      // Mode démo : retourner un utilisateur fictif si pas de session
      const isDev = process.env.NODE_ENV === 'development';
      if (isDev) {
        return {
          id: 1,
          openId: 'demo-admin-001',
          name: 'Admin Demo',
          email: 'admin@majestic-south.com',
          role: 'admin',
          createdAt: new Date(),
          lastSignedIn: new Date(),
          loginMethod: null,
        };
      }
      return null;
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  dashboard: router({
    getStats: publicProcedure.query(async () => {
      const missions = await getAllMissions();
      const demands = await getAllDemands();
      const quotes = await getAllQuotes();
      const chauffeurs = await getAllChauffeurs();
      const vehicles = await getAllVehicles();
      const alerts = await getAllAlerts();
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayMissions = missions.filter(m => {
        const d = new Date(m.date);
        d.setHours(0, 0, 0, 0);
        return d.getTime() === today.getTime();
      });
      return {
        totalMissions: missions.length,
        todayMissions: todayMissions.length,
        newDemands: demands.filter(d => d.status === 'nouvelle').length,
        pendingQuotes: quotes.filter(q => q.status === 'brouillon').length,
        availableChauffeurs: chauffeurs.filter(c => c.status === 'disponible').length,
        availableVehicles: vehicles.filter(v => v.status === 'disponible').length,
        urgentAlerts: alerts.filter(a => a.priority === 'urgente' && a.status === 'active').length,
      };
    }),
  }),

  clients: router({
    getAll: publicProcedure.query(async () => await getAllClients()),
    list: publicProcedure.query(async () => await getAllClients()),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => await getClientById(input.id)),
    create: publicProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().optional(),
        phone: z.string().min(1),
        company: z.string().optional(),
        type: z.enum(['particulier', 'business', 'hotel', 'agence', 'partenaire', 'vip']).optional(),
        address: z.string().optional(),
        preferences: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => await createClient(input)),
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        email: z.string().optional(),
        phone: z.string().optional(),
        company: z.string().optional(),
        type: z.enum(['particulier', 'business', 'hotel', 'agence', 'partenaire', 'vip']).optional(),
        address: z.string().optional(),
        preferences: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await updateClient(id, data);
      }),
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => await deleteClient(input.id)),
  }),

  chauffeurs: router({
    getAll: publicProcedure.query(async () => await getAllChauffeurs()),
    list: publicProcedure.query(async () => await getAllChauffeurs()),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => await getChauffeurById(input.id)),
    create: publicProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().optional(),
        phone: z.string().min(1),
        languages: z.string().optional(),
        zones: z.string().optional(),
        status: z.enum(['disponible', 'occupe', 'indisponible', 'conge', 'suspendu']).optional(),
        type: z.enum(['interne', 'partenaire']).optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => await createChauffeur(input)),
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        email: z.string().optional(),
        phone: z.string().optional(),
        languages: z.string().optional(),
        zones: z.string().optional(),
        status: z.enum(['disponible', 'occupe', 'indisponible', 'conge', 'suspendu']).optional(),
        type: z.enum(['interne', 'partenaire']).optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await updateChauffeur(id, data);
      }),
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => await deleteChauffeur(input.id)),
  }),

  vehicles: router({
    getAll: publicProcedure.query(async () => await getAllVehicles()),
    list: publicProcedure.query(async () => await getAllVehicles()),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => await getVehicleById(input.id)),
    create: publicProcedure
      .input(z.object({
        brand: z.string().min(1),
        model: z.string().min(1),
        registration: z.string().min(1),
        category: z.string().min(1),
        seats: z.number().optional(),
        luggage: z.number().optional(),
        color: z.string().optional(),
        year: z.number().optional(),
        mileage: z.number().optional(),
        status: z.enum(['disponible', 'reserve', 'en_mission', 'entretien', 'indisponible', 'hors_service']).optional(),
        nextMaintenance: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { nextMaintenance, ...rest } = input;
        return await createVehicle({
          ...rest,
          nextMaintenance: nextMaintenance ? new Date(nextMaintenance) : undefined,
        });
      }),
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        brand: z.string().optional(),
        model: z.string().optional(),
        registration: z.string().optional(),
        category: z.string().optional(),
        seats: z.number().optional(),
        luggage: z.number().optional(),
        color: z.string().optional(),
        year: z.number().optional(),
        mileage: z.number().optional(),
        status: z.enum(['disponible', 'reserve', 'en_mission', 'entretien', 'indisponible', 'hors_service']).optional(),
        nextMaintenance: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, nextMaintenance, ...rest } = input;
        return await updateVehicle(id, {
          ...rest,
          nextMaintenance: nextMaintenance ? new Date(nextMaintenance) : undefined,
        });
      }),
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => await deleteVehicle(input.id)),
  }),

  demands: router({
    getAll: publicProcedure.query(async () => {
      const demands = await getAllDemands();
      const clients = await getAllClients();
      return demands.map((d: any) => ({
        ...d,
        clientName: clients.find((c: any) => c.id === d.clientId)?.name ?? null,
      }));
    }),
    list: publicProcedure.query(async () => {
      const demands = await getAllDemands();
      const clients = await getAllClients();
      return demands.map((d: any) => ({
        ...d,
        clientName: clients.find((c: any) => c.id === d.clientId)?.name ?? null,
      }));
    }),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const d = await getDemandById(input.id);
        if (!d) return null;
        const clients = await getAllClients();
        return { ...d, clientName: clients.find((c: any) => c.id === (d as any).clientId)?.name ?? null };
      }),
    create: publicProcedure
      .input(z.object({
        clientId: z.number(),
        type: z.string().min(1),
        origin: z.string().min(1),
        destination: z.string().min(1),
        date: z.string(),
        passengers: z.number().optional(),
        luggage: z.number().optional(),
        vehicleType: z.string().optional(),
        message: z.string().optional(),
        status: z.enum(['nouvelle', 'a_traiter', 'devis_envoye', 'en_attente', 'convertie', 'refusee', 'annulee']).optional(),
        priority: z.enum(['basse', 'normale', 'haute', 'urgente']).optional(),
        source: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { date, ...rest } = input;
        return await createDemand({ ...rest, date: new Date(date) });
      }),
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        type: z.string().optional(),
        origin: z.string().optional(),
        destination: z.string().optional(),
        date: z.string().optional(),
        passengers: z.number().optional(),
        luggage: z.number().optional(),
        vehicleType: z.string().optional(),
        message: z.string().optional(),
        status: z.enum(['nouvelle', 'a_traiter', 'devis_envoye', 'en_attente', 'convertie', 'refusee', 'annulee']).optional(),
        priority: z.enum(['basse', 'normale', 'haute', 'urgente']).optional(),
        assignedTo: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, date, ...rest } = input;
        return await updateDemand(id, {
          ...rest,
          date: date ? new Date(date) : undefined,
        });
      }),
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => await deleteDemand(input.id)),
  }),

  missions: router({
    getAll: publicProcedure.query(async () => {
      const missions = await getAllMissions();
      const clients = await getAllClients();
      const chauffeurs = await getAllChauffeurs();
      const vehicles = await getAllVehicles();
      return missions.map((m: any) => ({
        ...m,
        startDate: m.startDate ?? m.date,
        number: m.number ?? `#${m.id}`,
        clientName: clients.find((c: any) => c.id === m.clientId)?.name ?? null,
        chauffeurName: chauffeurs.find((c: any) => c.id === m.chauffeurId)?.name ?? null,
        vehicleName: vehicles.find((v: any) => v.id === m.vehicleId) ? `${vehicles.find((v: any) => v.id === m.vehicleId)?.brand} ${vehicles.find((v: any) => v.id === m.vehicleId)?.model}` : null,
      }));
    }),
    list: publicProcedure.query(async () => {
      const missions = await getAllMissions();
      const clients = await getAllClients();
      const chauffeurs = await getAllChauffeurs();
      const vehicles = await getAllVehicles();
      return missions.map((m: any) => ({
        ...m,
        startDate: m.startDate ?? m.date,
        number: m.number ?? `#${m.id}`,
        clientName: clients.find((c: any) => c.id === m.clientId)?.name ?? null,
        chauffeurName: chauffeurs.find((c: any) => c.id === m.chauffeurId)?.name ?? null,
        vehicleName: vehicles.find((v: any) => v.id === m.vehicleId) ? `${vehicles.find((v: any) => v.id === m.vehicleId)?.brand} ${vehicles.find((v: any) => v.id === m.vehicleId)?.model}` : null,
      }));
    }),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const m = await getMissionById(input.id);
        if (!m) return null;
        const clients = await getAllClients();
        const chauffeurs = await getAllChauffeurs();
        const vehicles = await getAllVehicles();
        return {
          ...m,
          startDate: (m as any).startDate ?? (m as any).date,
          number: (m as any).number ?? `#${m.id}`,
          clientName: clients.find((c: any) => c.id === (m as any).clientId)?.name ?? null,
          chauffeurName: chauffeurs.find((c: any) => c.id === (m as any).chauffeurId)?.name ?? null,
          vehicleName: (() => { const v = vehicles.find((v: any) => v.id === (m as any).vehicleId); return v ? `${v.brand} ${v.model}` : null; })(),
        };
      }),
    create: publicProcedure
      .input(z.object({
        number: z.string().min(1),
        clientId: z.number(),
        chauffeurId: z.number().optional(),
        vehicleId: z.number().optional(),
        quoteId: z.number().optional(),
        type: z.string().min(1),
        origin: z.string().min(1),
        destination: z.string().min(1),
        date: z.string(),
        passengers: z.number().optional(),
        luggage: z.number().optional(),
        price: z.number().optional(),
        priceHT: z.number().optional(),
        paymentStatus: z.enum(['non_paye', 'paye', 'remboursement']).optional(),
        paymentMethod: z.string().optional(),
        status: z.enum(['a_confirmer', 'confirmee', 'en_preparation', 'chauffeur_assigne', 'vehicule_assigne', 'prete', 'en_cours', 'client_pris_en_charge', 'terminee', 'annulee', 'litige']).optional(),
        notes: z.string().optional(),
        specialInstructions: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { date, ...rest } = input;
        return await createMission({ ...rest, date: new Date(date) });
      }),
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        chauffeurId: z.number().optional(),
        vehicleId: z.number().optional(),
        date: z.string().optional(),
        price: z.number().optional(),
        priceHT: z.number().optional(),
        paymentStatus: z.enum(['non_paye', 'paye', 'remboursement']).optional(),
        paymentMethod: z.string().optional(),
        status: z.enum(['a_confirmer', 'confirmee', 'en_preparation', 'chauffeur_assigne', 'vehicule_assigne', 'prete', 'en_cours', 'client_pris_en_charge', 'terminee', 'annulee', 'litige']).optional(),
        notes: z.string().optional(),
        specialInstructions: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, date, ...rest } = input;
        return await updateMission(id, {
          ...rest,
          date: date ? new Date(date) : undefined,
        });
      }),
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => await deleteMission(input.id)),
  }),

  quotes: router({
    getAll: publicProcedure.query(async () => {
      const quotes = await getAllQuotes();
      const demands = await getAllDemands();
      const clients = await getAllClients();
      return quotes.map((q: any) => {
        const demand = demands.find((d: any) => d.id === q.demandId);
        const client = demand ? clients.find((c: any) => c.id === demand.clientId) : null;
        return { ...q, clientName: client?.name ?? null, demandOrigin: demand?.origin ?? null, demandDestination: demand?.destination ?? null };
      });
    }),
    list: publicProcedure.query(async () => {
      const quotes = await getAllQuotes();
      const demands = await getAllDemands();
      const clients = await getAllClients();
      return quotes.map((q: any) => {
        const demand = demands.find((d: any) => d.id === q.demandId);
        const client = demand ? clients.find((c: any) => c.id === demand.clientId) : null;
        return { ...q, clientName: client?.name ?? null, demandOrigin: demand?.origin ?? null, demandDestination: demand?.destination ?? null };
      });
    }),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const q = await getQuoteById(input.id);
        if (!q) return null;
        const demands = await getAllDemands();
        const clients = await getAllClients();
        const demand = demands.find((d: any) => d.id === (q as any).demandId);
        const client = demand ? clients.find((c: any) => c.id === demand.clientId) : null;
        return { ...q, clientName: client?.name ?? null, demandOrigin: demand?.origin ?? null, demandDestination: demand?.destination ?? null };
      }),
    create: publicProcedure
      .input(z.object({
        demandId: z.number(),
        number: z.string().min(1),
        price: z.number(),
        priceHT: z.number(),
        status: z.enum(['brouillon', 'envoye', 'consulte', 'accepte', 'refuse', 'expire']).optional(),
        validUntil: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { validUntil, ...rest } = input;
        return await createQuote({
          ...rest,
          validUntil: validUntil ? new Date(validUntil) : undefined,
        });
      }),
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        price: z.number().optional(),
        priceHT: z.number().optional(),
        status: z.enum(['brouillon', 'envoye', 'consulte', 'accepte', 'refuse', 'expire']).optional(),
        validUntil: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, validUntil, ...rest } = input;
        return await updateQuote(id, {
          ...rest,
          validUntil: validUntil ? new Date(validUntil) : undefined,
        });
      }),
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => await deleteQuote(input.id)),
    convertToMission: publicProcedure
      .input(z.object({
        quoteId: z.number(),
        chauffeurId: z.number().optional(),
        vehicleId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const quote = await getQuoteById(input.quoteId);
        if (!quote) throw new Error("Quote not found");
        const demand = await getDemandById(quote.demandId);
        if (!demand) throw new Error("Demand not found");
        const missionNumber = `MSN-${Date.now()}`;
        await createMission({
          number: missionNumber,
          clientId: demand.clientId,
          quoteId: input.quoteId,
          chauffeurId: input.chauffeurId,
          vehicleId: input.vehicleId,
          type: demand.type,
          origin: demand.origin,
          destination: demand.destination,
          date: demand.date,
          passengers: demand.passengers ?? 1,
          luggage: demand.luggage ?? 0,
          price: quote.price,
          priceHT: quote.priceHT,
          status: 'a_confirmer',
        });
        await updateQuote(input.quoteId, { status: 'accepte' });
        await updateDemand(demand.id, { status: 'convertie' });
        return { success: true, missionNumber };
      }),
  }),

  alerts: router({
    getAll: publicProcedure.query(async () => await getAllAlerts()),
    list: publicProcedure.query(async () => await getAllAlerts()),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => await getAlertById(input.id)),
    create: publicProcedure
      .input(z.object({
        type: z.string().min(1),
        title: z.string().min(1),
        message: z.string().optional(),
        priority: z.enum(['basse', 'normale', 'haute', 'urgente']).optional(),
        relatedEntity: z.string().optional(),
        relatedId: z.number().optional(),
        status: z.enum(['active', 'lue', 'resolue']).optional(),
      }))
      .mutation(async ({ input }) => await createAlert(input)),
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(['active', 'lue', 'resolue']).optional(),
        priority: z.enum(['basse', 'normale', 'haute', 'urgente']).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await updateAlert(id, data);
      }),
    resolve: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => await updateAlert(input.id, { status: 'resolue' })),
    dismiss: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => await updateAlert(input.id, { status: 'lue' })),
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => await deleteAlert(input.id)),
  }),

  search: router({
    global: publicProcedure
      .input(z.object({ query: z.string().min(1) }))
      .query(async ({ input }) => {
        const { query } = input;
        const q = query.toLowerCase();
        const [missions, clients, chauffeurs, demands, quotes] = await Promise.all([
          getAllMissions(),
          getAllClients(),
          getAllChauffeurs(),
          getAllDemands(),
          getAllQuotes(),
        ]);
        return {
          missions: missions.filter(m =>
            (m.origin || '').toLowerCase().includes(q) ||
            (m.destination || '').toLowerCase().includes(q) ||
            (m.status || '').toLowerCase().includes(q)
          ).slice(0, 5),
          clients: clients.filter(c =>
            (c.name || '').toLowerCase().includes(q) ||
            (c.email || '').toLowerCase().includes(q) ||
            (c.company || '').toLowerCase().includes(q)
          ).slice(0, 5),
          chauffeurs: chauffeurs.filter(c =>
            (c.name || '').toLowerCase().includes(q) ||
            (c.email || '').toLowerCase().includes(q)
          ).slice(0, 5),
          demands: demands.filter(d =>
            (d.origin || '').toLowerCase().includes(q) ||
            (d.destination || '').toLowerCase().includes(q)
          ).slice(0, 5),
          quotes: quotes.filter(q2 =>
            (q2.status || '').toLowerCase().includes(q)
          ).slice(0, 5),
        };
      }),
  }),

  history: router({
    list: publicProcedure
      .input(z.object({
        limit: z.number().optional().default(50),
        status: z.string().optional(),
      }))
      .query(async ({ input }) => {
        const missions = await getAllMissions();
        let filtered = missions;
        if (input.status) {
          filtered = missions.filter(m => m.status === input.status);
        }
        return filtered
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
          .slice(0, input.limit);
      }),
  }),

  invoices: router({
    list: publicProcedure.query(async () => {
      const missions = await getAllMissions();
      return missions
        .filter(m => m.status === 'terminee' || m.status === 'en_cours')
        .map(m => ({
          id: m.id,
          missionId: m.id,
          number: `FAC-${String(m.id).padStart(4, '0')}`,
          origin: m.origin,
          destination: m.destination,
          date: m.date,
          amount: m.price || 0,
          status: m.status === 'terminee' ? 'payee' : 'en_attente',
          clientId: m.clientId,
        }));
    }),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const mission = await getMissionById(input.id);
        if (!mission) return null;
        return {
          id: mission.id,
          missionId: mission.id,
          number: `FAC-${String(mission.id).padStart(4, '0')}`,
          origin: mission.origin,
          destination: mission.destination,
          date: mission.date,
          amount: mission.price || 0,
          status: mission.status === 'terminee' ? 'payee' : 'en_attente',
          clientId: mission.clientId,
        };
      }),
  }),

  payments: router({
    list: publicProcedure.query(async () => {
      const missions = await getAllMissions();
      return missions
        .filter(m => m.status === 'terminee' && m.price)
        .map(m => ({
          id: m.id,
          missionId: m.id,
          reference: `PAY-${String(m.id).padStart(4, '0')}`,
          origin: m.origin,
          destination: m.destination,
          date: m.date,
          amount: m.price || 0,
          method: 'virement',
          status: 'recu',
          clientId: m.clientId,
        }));
    }),
    stats: publicProcedure.query(async () => {
      const missions = await getAllMissions();
      const completed = missions.filter(m => m.status === 'terminee');
      const totalRevenue = completed.reduce((sum, m) => sum + (m.price || 0), 0);
      const pending = missions.filter(m => m.status === 'en_cours');
      const pendingRevenue = pending.reduce((sum, m) => sum + (m.price || 0), 0);
      return {
        totalRevenue,
        pendingRevenue,
        completedCount: completed.length,
        pendingCount: pending.length,
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;
